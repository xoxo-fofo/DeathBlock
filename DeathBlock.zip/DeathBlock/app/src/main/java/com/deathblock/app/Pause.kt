package com.deathblock.app

import android.content.Context

/**
 * Off controls.
 *  - DEBUG_SWITCH: testing ke liye instant ON/OFF button. Release se pehle false kar do.
 *  - request -> DELAY_MIN wait -> OFF_MIN window (permanent friction wala switch)
 */
object Pause {
    const val DEBUG_SWITCH = true
    const val DELAY_MIN = 15L
    const val OFF_MIN = 10L

    private const val MIN = 60_000L
    private fun sp(c: Context) = c.getSharedPreferences("db", Context.MODE_PRIVATE)

    fun debugOff(c: Context) = DEBUG_SWITCH && sp(c).getBoolean("debugOff", false)
    fun setDebugOff(c: Context, v: Boolean) { sp(c).edit().putBoolean("debugOff", v).apply() }

    fun isOff(c: Context) = debugOff(c) || isWindowOff(c)
    fun isWindowOff(c: Context) = System.currentTimeMillis() < sp(c).getLong("offUntil", 0)
    fun offLeftMin(c: Context) = ((sp(c).getLong("offUntil", 0) - System.currentTimeMillis()) / MIN + 1).coerceAtLeast(0)

    fun request(c: Context) { sp(c).edit().putLong("requestAt", System.currentTimeMillis()).apply() }
    fun cancel(c: Context) { sp(c).edit().remove("requestAt").remove("offUntil").apply() }

    /** -1 = request nahi hui, 0 = ready, >0 = minutes baaki */
    fun waitLeftMin(c: Context): Long {
        val r = sp(c).getLong("requestAt", 0); if (r == 0L) return -1
        return ((r + DELAY_MIN * MIN - System.currentTimeMillis()) / MIN + 1).coerceAtLeast(0)
    }

    fun turnOff(c: Context) {
        sp(c).edit().putLong("offUntil", System.currentTimeMillis() + OFF_MIN * MIN).remove("requestAt").apply()
    }

    fun setReason(c: Context, s: String) { sp(c).edit().putString("reason", s).apply() }
    fun getReason(c: Context) = sp(c).getString("reason", "-") ?: "-"
}
