package com.deathblock.app

import android.content.Context

/** Local-only block log (kab, kaunsi app, kya block hua). Max 500 entries. */
object Stats {
    data class Ev(val t: Long, val pkg: String, val what: String)

    private const val MAX = 500
    private fun sp(c: Context) = c.getSharedPreferences("stats", Context.MODE_PRIVATE)

    fun add(c: Context, pkg: String, what: String) {
        val clean = what.replace('\n', ' ').replace('\t', ' ').take(140)
        val line = "${System.currentTimeMillis()}\t$pkg\t$clean"
        val old = sp(c).getString("log", "") ?: ""
        val lines = if (old.isEmpty()) mutableListOf() else old.split('\n').toMutableList()
        lines.add(line)
        while (lines.size > MAX) lines.removeAt(0)
        val total = sp(c).getLong("total", 0) + 1
        sp(c).edit().putString("log", lines.joinToString("\n")).putLong("total", total).apply()
    }

    fun total(c: Context) = sp(c).getLong("total", 0)

    fun all(c: Context): List<Ev> {
        val raw = sp(c).getString("log", "") ?: ""
        if (raw.isEmpty()) return emptyList()
        return raw.split('\n').mapNotNull {
            val p = it.split('\t')
            val t = p.getOrNull(0)?.toLongOrNull()
            if (p.size < 3 || t == null) null else Ev(t, p[1], p[2])
        }
    }

    fun clear(c: Context) { sp(c).edit().clear().apply() }
}
