package com.deathblock.app

import android.content.Context

class Matcher(private val domains: List<String>, keywords: List<String>) {

    private val urlRegex = Regex("porn|xxx|hentai|nsfw|rule34")
    private val kwRegex = Regex(keywords.joinToString("|") { "\\b" + Regex.escape(it) + "\\b" })

    fun urlBad(url: String): Boolean {
        val u = url.lowercase()
        return domains.any { u.contains(it) } || urlRegex.containsMatchIn(u)
    }

    /** Screen text: kam se kam 3 points chahiye (keyword = 1, domain = 2). */
    fun textBad(text: String): Boolean {
        val t = text.lowercase()
        var score = kwRegex.findAll(t).map { it.value }.toSet().size
        score += domains.count { t.contains(it) } * 2
        return score >= 3
    }

    companion object {
        fun load(ctx: Context): Matcher {
            fun read(name: String) = ctx.assets.open(name).bufferedReader().readLines()
                .map { it.trim().lowercase() }.filter { it.isNotEmpty() }
            return Matcher(read("domains.txt"), read("keywords.txt"))
        }
    }
}
