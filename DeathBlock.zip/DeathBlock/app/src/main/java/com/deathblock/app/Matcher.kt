package com.deathblock.app

import android.content.Context

enum class Verdict { BLOCK, TRUSTED, UNKNOWN }

data class Result(val blocked: Boolean, val score: Int, val hits: List<String>)

class Matcher(
    private val adultDomains: List<String>,
    private val trustedDomains: List<String>,
    private val trustedApps: Set<String>,
    phrases: List<Pair<Int, String>>
) {
    private class Phrase(val w: Int, val text: String, val re: Regex)

    private val ps = phrases.map { (w, t) -> Phrase(w, t, build(t)) }

    private val domainRe: Regex? = if (adultDomains.isEmpty()) null else
        Regex("(?<![\\p{L}\\p{N}])(" + adultDomains.joinToString("|") { Regex.escape(it) } + ")(?![\\p{L}\\p{N}])")

    private val hostWordRe = Regex("porn|xxx|hentai")
    private val tokenRe = Regex("(?<![a-z])(porn|xxx|hentai)(?![a-z])")
    private val zeroWidth = Regex("[\\u200B-\\u200D\\uFEFF]")

    private fun build(t: String): Regex {
        val body = t.trim().split(Regex("\\s+")).joinToString("[\\s_\\-.]+") { Regex.escape(it) }
        return Regex("(?<![\\p{L}\\p{N}])${body}(s|es)?(?![\\p{L}\\p{N}])")
    }

    fun isTrustedApp(pkg: String) = pkg in trustedApps

    private fun hostOf(low: String): String? {
        if (low.isEmpty() || low.contains(' ')) return null
        var s = low.substringAfter("://")
        s = s.substringBefore('/').substringBefore('?').substringBefore('#')
            .substringAfter('@').substringBefore(':')
        if (s.startsWith("www.")) s = s.removePrefix("www.")
        return if (s.contains('.')) s else null
    }

    /** URL bar ka text: BLOCK / TRUSTED (scan skip) / UNKNOWN (screen scan karo). */
    fun urlVerdict(raw: String): Pair<Verdict, String> {
        val low = raw.trim().lowercase()
        val host = hostOf(low)
        if (host == null) {
            // URL nahi, typed search query
            return if (tokenRe.containsMatchIn(low)) Verdict.BLOCK to "query word" else Verdict.UNKNOWN to ""
        }
        if (trustedDomains.any { host == it || host.endsWith(".$it") }) return Verdict.TRUSTED to host
        adultDomains.firstOrNull { host.contains(it) }?.let { return Verdict.BLOCK to "domain $it" }
        hostWordRe.find(host)?.let { return Verdict.BLOCK to "host word ${it.value}" }
        val path = low.substringAfter(host, "")
        tokenRe.find(path)?.let { return Verdict.BLOCK to "url word ${it.value}" }
        return Verdict.UNKNOWN to host
    }

    /** Multi-phrase scoring. Block jab score >= THRESHOLD. */
    fun scoreText(text: String): Result {
        if (text.length < 8) return Result(false, 0, emptyList())
        val t = zeroWidth.replace(text.lowercase(), "")
        var score = 0
        val hits = ArrayList<String>()
        for (p in ps) {
            if (p.re.containsMatchIn(t)) { score += p.w; hits.add("${p.w}: ${p.text}") }
        }
        domainRe?.findAll(t)?.map { it.value }?.toSet()?.forEach {
            score += 3; hits.add("3: site $it")
        }
        return Result(score >= THRESHOLD, score, hits)
    }

    companion object {
        const val THRESHOLD = 5

        fun load(ctx: Context): Matcher {
            fun read(name: String) = ctx.assets.open(name).bufferedReader().readLines()
                .map { it.trim().lowercase() }.filter { it.isNotEmpty() && !it.startsWith("#") }
            val phrases = read("phrases.txt").mapNotNull {
                val i = it.indexOf('|'); if (i < 1) null else {
                    val w = it.substring(0, i).trim().toIntOrNull()
                    if (w == null) null else w to it.substring(i + 1).trim()
                }
            }
            return Matcher(read("domains.txt"), read("trusted_domains.txt"),
                read("trusted_apps.txt").toSet(), phrases)
        }
    }
}
