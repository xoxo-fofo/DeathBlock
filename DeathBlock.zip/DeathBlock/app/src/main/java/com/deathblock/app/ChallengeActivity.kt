package com.deathblock.app

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.view.WindowManager
import android.widget.*
import java.security.SecureRandom

/** EditText jisme paste / selection menu band hai. */
class NoPasteEditText(ctx: Context) : EditText(ctx) {
    private val cb = object : ActionMode.Callback {
        override fun onCreateActionMode(m: ActionMode?, menu: Menu?) = false
        override fun onPrepareActionMode(m: ActionMode?, menu: Menu?) = false
        override fun onActionItemClicked(m: ActionMode?, i: MenuItem?) = false
        override fun onDestroyActionMode(m: ActionMode?) {}
    }

    init {
        customSelectionActionModeCallback = cb
        if (Build.VERSION.SDK_INT >= 23) customInsertionActionModeCallback = cb
        isLongClickable = false
    }

    override fun onTextContextMenuItem(id: Int): Boolean {
        if (id == android.R.id.paste || id == android.R.id.pasteAsPlainText) return true
        return super.onTextContextMenuItem(id)
    }
}

class ChallengeActivity : Activity() {
    private val LEN = 200
    private lateinit var target: String
    private lateinit var input: NoPasteEditText
    private lateinit var prog: TextView
    private var last = ""
    private var reverting = false
    private var clearing = false

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { clearClip() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Screenshot / screen-record / recents preview band
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)

        target = generate()
        val shown = target.chunked(20).joinToString("\n") { it.chunked(5).joinToString(" ") }

        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32) }
        l.addView(TextView(this).apply {
            textSize = 16f
            text = "Protection OFF karne ke liye ye $LEN characters bilkul waise hi type karein.\n" +
                "Copy-paste band hai. Spaces/line breaks sirf padhne ke liye hain, unhe type karna zaroori nahi.\n" +
                "Upper/lower case dhyan se."
        })
        l.addView(TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 17f
            setPadding(0, 32, 0, 32)
            text = shown
            setTextIsSelectable(false)
            isLongClickable = false
        })
        input = NoPasteEditText(this).apply {
            hint = "Yahan type karein"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or
                InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 4
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(e: Editable?) {
                    if (e == null || reverting) return
                    val cur = e.toString()
                    // Ek saath 2 se zyada characters aaye = paste/keyboard-clipboard -> wapas
                    if (cur.length - last.length > 2) {
                        reverting = true
                        e.replace(0, e.length, last)
                        reverting = false
                        return
                    }
                    last = cur
                    updateProgress()
                }
            })
        }
        prog = TextView(this).apply { textSize = 14f; setPadding(0, 16, 0, 16) }
        val btn = Button(this).apply {
            text = "Confirm"
            setOnClickListener { confirm() }
        }
        l.addView(input); l.addView(prog); l.addView(btn)
        val sv = ScrollView(this); sv.addView(l); setContentView(sv)
        updateProgress()
    }

    private fun typed() = input.text.toString().filter { !it.isWhitespace() }

    private fun updateProgress() {
        val t = typed()
        val ok = t.commonPrefixWith(target).length
        prog.text = "Typed: ${t.length}/$LEN   Sahi: $ok" +
            (if (t.length > ok) "\nCharacter #${ok + 1} galat hai" else "")
    }

    private fun confirm() {
        if (typed() == target) {
            Pause.turnOff(this)
            Toast.makeText(this, "Protection ${Pause.OFF_MIN} min ke liye OFF", Toast.LENGTH_LONG).show()
            finish()
        } else {
            Toast.makeText(this, "Match nahi hua", Toast.LENGTH_SHORT).show()
        }
    }

    private fun generate(): String {
        // Confusing chars (O,0,I,l,1) hata diye
        val cs = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#%&*?+="
        val r = SecureRandom()
        return String(CharArray(LEN) { cs[r.nextInt(cs.length)] })
    }

    private fun clearClip() {
        if (clearing) return
        clearing = true
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            if (Build.VERSION.SDK_INT >= 28) cm.clearPrimaryClip()
            else cm.setPrimaryClip(ClipData.newPlainText("", ""))
        } catch (_: Exception) {}
        clearing = false
    }

    override fun onStart() {
        super.onStart()
        clearClip()
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).addPrimaryClipChangedListener(clipListener)
    }

    override fun onStop() {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).removePrimaryClipChangedListener(clipListener)
        super.onStop()
    }
}
