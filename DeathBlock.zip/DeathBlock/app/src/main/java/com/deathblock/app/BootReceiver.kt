package com.deathblock.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Accessibility service ko Android khud boot par start kar deta hai (agar enabled ho).
 * Ye receiver sirf check karta hai: agar service band mili to notification deta hai.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (MainActivity.isServiceOn(ctx)) return
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val id = "deathblock"
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    NotificationChannel(id, "DeathBlock", NotificationManager.IMPORTANCE_HIGH))
            }
            val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE)
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, id)
                    else Notification.Builder(ctx)
            nm.notify(1, b.setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("DeathBlock band hai")
                .setContentText("Accessibility dobara ON karne ke liye tap karein")
                .setContentIntent(pi).setAutoCancel(true).build())
        } catch (_: Exception) {}
    }
}
