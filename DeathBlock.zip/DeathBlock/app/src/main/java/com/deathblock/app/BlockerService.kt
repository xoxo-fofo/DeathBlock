package com.deathblock.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class BlockerService : AccessibilityService() {

    private var matcher: Matcher? = null
    private var lastBlock = 0L
    private var lastScan = 0L

    private val guardKeys = listOf(
        "settings", "packageinstaller", "permissioncontroller",
        "securitycenter", "safecenter", "appmanager"
    )

    /**
     * Sirf DeathBlock ke apne sensitive pages: App Info, Uninstall dialog,
     * aur DeathBlock ka accessibility detail page. Accessibility ki list ya
     * baaki services ke pages me ye markers nahi hote, isliye wo khule rehte hain.
     */
    private val guardMarkers = listOf(
        "uninstall", "force stop", "clear data", "clear storage",
        "storage & cache", "storage and cache", "app info", "app details",
        "use deathblock", "stop deathblock", "turn off deathblock",
        "full control", "view and control screen", "view screen and take action",
        "अनइंस्टॉल", "फ़ोर्स स्टॉप", "जबरन रोकें", "ऐप की जानकारी", "ऐप्लिकेशन की जानकारी"
    )

    private val urlIdSuffixes = listOf(
        "url_bar", "url_field", "location_bar_edit_text",
        "mozac_browser_toolbar_url_view", "url_bar_title", "omnibarTextInput"
    )
    private val browsers = setOf(
        "com.android.chrome", "com.brave.browser", "com.microsoft.emmx",
        "org.mozilla.firefox", "org.mozilla.fenix", "com.opera.browser",
        "com.opera.mini.native", "com.sec.android.app.sbrowser",
        "com.duckduckgo.mobile.android", "com.kiwibrowser.browser",
        "com.vivaldi.browser", "com.google.android.apps.chrome"
    )

    override fun onServiceConnected() {
        matcher = Matcher.load(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val m = matcher ?: return
        if (Pause.isOff(this)) return
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return

        // 1) Self-protection (sirf DeathBlock ke apne pages)
        val pl = pkg.lowercase()
        if (guardKeys.any { pl.contains(it) }) {
            val sb = StringBuilder()
            collect(root, sb, 0)
            val t = sb.toString().lowercase()
            if (t.contains("deathblock") && guardMarkers.any { t.contains(it) }) {
                performGlobalAction(GLOBAL_ACTION_HOME)
            }
            return
        }

        // 2) Trusted apps skip
        if (m.isTrustedApp(pkg)) return

        // throttle
        val now = System.currentTimeMillis()
        if (now - lastScan < 400) return
        lastScan = now

        // 3) Browser URL: block / trusted-skip / unknown
        if (pkg in browsers) {
            val url = findUrl(root, pkg)
            if (url != null) {
                val (v, why) = m.urlVerdict(url)
                when (v) {
                    Verdict.BLOCK -> { block(pkg, "URL: $why"); return }
                    Verdict.TRUSTED -> return
                    Verdict.UNKNOWN -> {}
                }
            }
        }

        // 4) Screen text scoring
        val sb = StringBuilder()
        collect(root, sb, 0)
        val r = m.scoreText(sb.toString())
        if (r.blocked) block(pkg, "score ${r.score} -> " + r.hits.joinToString("; "))
    }

    private fun findUrl(root: AccessibilityNodeInfo, pkg: String): String? {
        for (s in urlIdSuffixes) {
            val nodes = root.findAccessibilityNodeInfosByViewId("$pkg:id/$s")
            val txt = nodes?.firstOrNull()?.text?.toString()
            if (!txt.isNullOrBlank()) return txt
        }
        return null
    }

    private fun collect(node: AccessibilityNodeInfo?, sb: StringBuilder, depth: Int) {
        if (node == null || depth > 30 || sb.length > 20000) return
        node.text?.let { sb.append(it).append(' ') }
        node.contentDescription?.let { sb.append(it).append(' ') }
        for (i in 0 until node.childCount) collect(node.getChild(i), sb, depth + 1)
    }

    private fun block(pkg: String, why: String) {
        val now = System.currentTimeMillis()
        if (now - lastBlock < 2000) return
        lastBlock = now
        Pause.setReason(this, "$pkg | $why")
        performGlobalAction(GLOBAL_ACTION_HOME)
        startActivity(
            Intent(this, BlockActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        )
    }

    override fun onInterrupt() {}
}
