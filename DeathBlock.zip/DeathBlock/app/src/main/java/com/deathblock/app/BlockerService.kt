package com.deathblock.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class BlockerService : AccessibilityService() {

    private var matcher: Matcher? = null
    private var lastBlock = 0L

    private val guardKeys = listOf(
        "settings", "packageinstaller", "permissioncontroller",
        "securitycenter", "safecenter", "appmanager"
    )
    private val urlIdSuffixes = listOf(
        "url_bar", "url_field", "location_bar_edit_text",
        "mozac_browser_toolbar_url_view", "url_bar_title", "omnibarTextInput"
    )
    private val browsers = setOf(
        "com.android.chrome", "com.brave.browser", "com.microsoft.emmx",
        "org.mozilla.firefox", "org.mozilla.fenix", "com.opera.browser",
        "com.opera.mini.native", "com.sec.android.app.sbrowser",
        "com.duckduckgo.mobile.android", "com.kiwibrowser.browser",
        "com.vivaldi.browser", "com.google.android.apps.chrome"
    )

    override fun onServiceConnected() {
        matcher = Matcher.load(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val m = matcher ?: return
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return

        // 1) Self-protection: sirf Settings/Installer me jab "DeathBlock" dikhe
        val pl = pkg.lowercase()
        if (guardKeys.any { pl.contains(it) }) {
            val sb = StringBuilder()
            collect(root, sb, 0)
            if (sb.contains("deathblock", ignoreCase = true)) {
                performGlobalAction(GLOBAL_ACTION_HOME)
            }
            return
        }

        // 2) Browser URL bar
        if (pkg in browsers) {
            val url = findUrl(root, pkg)
            if (url != null && m.urlBad(url)) { block(); return }
        }

        // 3) Poori screen ka text
        val sb = StringBuilder()
        collect(root, sb, 0)
        if (m.textBad(sb.toString())) block()
    }

    private fun findUrl(root: AccessibilityNodeInfo, pkg: String): String? {
        for (s in urlIdSuffixes) {
            val nodes = root.findAccessibilityNodeInfosByViewId("$pkg:id/$s")
            val txt = nodes?.firstOrNull()?.text?.toString()
            if (!txt.isNullOrBlank()) return txt
        }
        return null
    }

    private fun collect(node: AccessibilityNodeInfo?, sb: StringBuilder, depth: Int) {
        if (node == null || depth > 30 || sb.length > 20000) return
        node.text?.let { sb.append(it).append(' ') }
        node.contentDescription?.let { sb.append(it).append(' ') }
        for (i in 0 until node.childCount) collect(node.getChild(i), sb, depth + 1)
    }

    private fun block() {
        val now = System.currentTimeMillis()
        if (now - lastBlock < 2000) return
        lastBlock = now
        performGlobalAction(GLOBAL_ACTION_HOME)
        startActivity(
            Intent(this, BlockActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        )
    }

    override fun onInterrupt() {}
}
