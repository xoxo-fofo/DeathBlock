package com.deathblock.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        status = TextView(this).apply { textSize = 18f; gravity = Gravity.CENTER }
        val b1 = Button(this).apply {
            text = "1. Accessibility ON karein"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val b2 = Button(this).apply {
            text = "2. Display over other apps allow karein"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
        l.addView(status); l.addView(b1); l.addView(b2)
        setContentView(l)
    }

    override fun onResume() {
        super.onResume()
        val acc = isServiceOn(this)
        val ovl = Settings.canDrawOverlays(this)
        status.text = "DeathBlock\n\nAccessibility: " + (if (acc) "ON" else "OFF") +
            "\nOverlay: " + (if (ovl) "ON" else "OFF")
    }

    companion object {
        fun isServiceOn(c: Context): Boolean {
            val s = Settings.Secure.getString(c.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            return s.contains(c.packageName + "/", ignoreCase = true)
        }
    }
}
