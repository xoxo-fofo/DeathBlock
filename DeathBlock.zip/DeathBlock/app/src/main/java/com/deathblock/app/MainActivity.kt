package com.deathblock.app

import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var title: TextView
    private lateinit var statsTop: TextView
    private lateinit var statsRecent: TextView
    private lateinit var bAppInfo: Button
    private lateinit var bOverlay: Button
    private lateinit var bNotif: Button
    private lateinit var bAcc: Button
    private lateinit var offBtn: Button
    private var dbgBtn: Button? = null
    private lateinit var testIn: EditText
    private lateinit var testOut: TextView
    private val matcher by lazy { Matcher.load(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 40, 40, 40)
        }
        title = TextView(this).apply { textSize = 15f }
        statsTop = TextView(this).apply { textSize = 14f; typeface = android.graphics.Typeface.MONOSPACE; setPadding(0, 24, 0, 24) }
        statsRecent = TextView(this).apply { textSize = 13f; setPadding(0, 24, 0, 24) }

        bAppInfo = Button(this).apply {
            setOnClickListener {
                getSharedPreferences("db", Context.MODE_PRIVATE).edit().putBoolean("appInfoOpened", true).apply()
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
        }
        bOverlay = Button(this).apply {
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        bNotif = Button(this).apply { setOnClickListener { openNotifSettings() } }
        bAcc = Button(this).apply {
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        offBtn = Button(this).apply { setOnClickListener { onOffClick() } }

        l.addView(title)
        l.addView(statsTop)
        l.addView(TextView(this).apply { text = "Permissions (Settings se):"; textSize = 15f })
        l.addView(bAppInfo); l.addView(bOverlay); l.addView(bNotif); l.addView(bAcc)

        if (Pause.DEBUG_SWITCH) {
            dbgBtn = Button(this).apply {
                setOnClickListener {
                    Pause.setDebugOff(this@MainActivity, !Pause.debugOff(this@MainActivity)); refresh()
                }
            }
            l.addView(dbgBtn)
        }
        l.addView(offBtn)
        l.addView(statsRecent)

        if (Pause.DEBUG_SWITCH) {
            testIn = EditText(this).apply {
                hint = "Test: URL ya text paste karein"
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                minLines = 3
            }
            testOut = TextView(this).apply { textSize = 14f }
            val tb = Button(this).apply {
                text = "Test karein"
                setOnClickListener {
                    val s = testIn.text.toString()
                    val (v, why) = matcher.urlVerdict(s)
                    val r = matcher.scoreText(s)
                    testOut.text = "URL: $v $why\nScore: ${r.score} (block >= ${Matcher.THRESHOLD}) -> " +
                        (if (r.blocked) "BLOCK" else "OK") + "\n" + r.hits.joinToString("\n")
                }
            }
            val clr = Button(this).apply {
                text = "DEBUG: stats clear"
                setOnClickListener { Stats.clear(this@MainActivity); refresh() }
            }
            l.addView(testIn); l.addView(tb); l.addView(testOut); l.addView(clr)
        }

        val sv = ScrollView(this); sv.addView(l); setContentView(sv)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun notifOn(): Boolean = try {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).areNotificationsEnabled()
    } catch (_: Exception) { true }

    private fun openNotifSettings() {
        val i = if (Build.VERSION.SDK_INT >= 26)
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
        else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        startActivity(i)
    }

    private fun mark(ok: Boolean) = if (ok) "✅" else "❌"

    private fun refresh() {
        val acc = isServiceOn(this)
        val ovl = Settings.canDrawOverlays(this)
        val nt = notifOn()

        title.text = "DeathBlock v1.3" +
            (if (Pause.debugOff(this)) "\n⚠ DEBUG: blocking BAND hai" else "") +
            (if (Pause.isWindowOff(this)) "\n⏸ PAUSED: ${Pause.offLeftMin(this)} min baaki" else "")

        bAppInfo.text = "1. App Info kholein → ⋮ → Allow restricted settings"
        bAppInfo.visibility = if (Build.VERSION.SDK_INT >= 33 && !acc) View.VISIBLE else View.GONE
        bOverlay.text = "${mark(ovl)} Display over other apps"
        bNotif.text = "${mark(nt)} Notifications"
        bAcc.text = "${mark(acc)} Accessibility service"

        dbgBtn?.text = if (Pause.debugOff(this)) "DEBUG: Blocking ON karein" else "DEBUG: Blocking OFF karein"
        offBtn.text = if (Pause.isWindowOff(this)) "Protection wapas ON karein"
        else "Protection OFF karna hai (200-char challenge)"

        renderStats()
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) { pkg }

    private fun renderStats() {
        val evs = Stats.all(this)
        val today = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val dayFmt = SimpleDateFormat("EEE dd MMM", Locale.getDefault())
        val sb = StringBuilder()
        sb.append("📊 Blocked statistics\n")
        sb.append("Aaj: ${evs.count { it.t >= today }}   Total: ${Stats.total(this)}\n\nPichle 7 din:\n")
        for (i in 6 downTo 0) {
            val s = Calendar.getInstance().apply { timeInMillis = today; add(Calendar.DAY_OF_YEAR, -i) }
            val e = Calendar.getInstance().apply { timeInMillis = s.timeInMillis; add(Calendar.DAY_OF_YEAR, 1) }
            val n = evs.count { it.t >= s.timeInMillis && it.t < e.timeInMillis }
            sb.append(dayFmt.format(s.time)).append("  ").append("█".repeat(minOf(n, 20))).append(' ').append(n).append('\n')
        }
        statsTop.text = sb.toString()

        val tf = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault())
        val r = StringBuilder("🕒 Recent blocks (last 25)\n")
        if (evs.isEmpty()) r.append("\nAbhi tak kuch block nahi hua.")
        for (e in evs.takeLast(25).reversed()) {
            r.append('\n').append(tf.format(Date(e.t))).append(" • ").append(appLabel(e.pkg))
                .append("\n   ").append(e.what).append('\n')
        }
        statsRecent.text = r.toString()
    }

    private fun onOffClick() {
        if (Pause.isWindowOff(this)) { Pause.cancel(this); refresh() }
        else startActivity(Intent(this, ChallengeActivity::class.java))
    }

    companion object {
        fun isServiceOn(c: Context): Boolean {
            val s = Settings.Secure.getString(c.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            return s.contains(c.packageName + "/", ignoreCase = true)
        }
    }
}
