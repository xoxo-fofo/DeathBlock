package com.deathblock.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var offBtn: Button
    private var dbgBtn: Button? = null
    private lateinit var testIn: EditText
    private lateinit var testOut: TextView
    private val matcher by lazy { Matcher.load(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 40, 40, 40)
        }
        status = TextView(this).apply { textSize = 15f }
        val b1 = Button(this).apply {
            text = "1. Accessibility ON karein"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val b2 = Button(this).apply {
            text = "2. Display over other apps allow karein"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
        l.addView(status); l.addView(b1); l.addView(b2)

        if (Pause.DEBUG_SWITCH) {
            dbgBtn = Button(this).apply {
                setOnClickListener { Pause.setDebugOff(this@MainActivity, !Pause.debugOff(this@MainActivity)); refresh() }
            }
            l.addView(dbgBtn)
        }

        offBtn = Button(this).apply { setOnClickListener { onOffClick() } }
        l.addView(offBtn)

        // Matcher tester (DEBUG): yahan URL ya text paste karke score dekho
        if (Pause.DEBUG_SWITCH) {
            testIn = EditText(this).apply {
                hint = "Test: URL ya text paste karein"
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                minLines = 3
            }
            testOut = TextView(this).apply { textSize = 14f }
            val tb = Button(this).apply {
                text = "Test karein"
                setOnClickListener {
                    val s = testIn.text.toString()
                    val (v, why) = matcher.urlVerdict(s)
                    val r = matcher.scoreText(s)
                    testOut.text = "URL: $v $why\nScore: ${r.score} (block >= ${Matcher.THRESHOLD}) -> " +
                        (if (r.blocked) "BLOCK" else "OK") + "\n" + r.hits.joinToString("\n")
                }
            }
            l.addView(testIn); l.addView(tb); l.addView(testOut)
        }

        val sv = ScrollView(this); sv.addView(l); setContentView(sv)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val acc = isServiceOn(this)
        val ovl = Settings.canDrawOverlays(this)
        status.text = "DeathBlock v1.2\n\nAccessibility: " + (if (acc) "ON" else "OFF") +
            "\nOverlay: " + (if (ovl) "ON" else "OFF") +
            (if (Pause.debugOff(this)) "\n\nDEBUG: blocking BAND hai" else "") +
            (if (Pause.isWindowOff(this)) "\n\nPAUSED: ${Pause.offLeftMin(this)} min baaki" else "") +
            "\n\nLast block:\n" + Pause.getReason(this)
        dbgBtn?.text = if (Pause.debugOff(this)) "DEBUG: Blocking ON karein" else "DEBUG: Blocking OFF karein"
        val w = Pause.waitLeftMin(this)
        offBtn.text = when {
            Pause.isWindowOff(this) -> "Protection wapas ON karein"
            w < 0 -> "Protection OFF request (${Pause.DELAY_MIN} min wait)"
            w > 0 -> "Wait: $w min baaki (tap = cancel)"
            else -> "Ab OFF karein (${Pause.OFF_MIN} min ke liye)"
        }
    }

    private fun onOffClick() {
        val w = Pause.waitLeftMin(this)
        when {
            Pause.isWindowOff(this) -> Pause.cancel(this)
            w < 0 -> Pause.request(this)
            w > 0 -> Pause.cancel(this)
            else -> Pause.turnOff(this)
        }
        refresh()
    }

    companion object {
        fun isServiceOn(c: Context): Boolean {
            val s = Settings.Secure.getString(c.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            return s.contains(c.packageName + "/", ignoreCase = true)
        }
    }
}
